"""
Точка входа.

День 1: загрузка конфига и вывод стартового состояния линии.
День 2: прогон нескольких тактов (tick) с выводом состояния после каждого.
День 3: демонстрация отправки кузова на доработку (send_to_rework) в середине прогона.
День 4: демонстрация возврата с доработки (return_to_line), смены приоритета
        (change_priority) и полного журнала событий в конце прогона.

Запуск:
    python src/main.py            # прогоняет 12 тактов по умолчанию
    python src/main.py 20         # прогоняет 20 тактов
"""

import sys
from pathlib import Path

from config_loader import load_config
from display import print_event_log, print_line_state
from engine import change_priority, return_to_line, send_to_rework, tick

DEFAULT_CONFIG_PATH = Path(__file__).parent.parent / "config" / "line_config.json"
DEFAULT_TICKS = 14

# Демонстрационный сценарий действий по тактам.
# Формат: {номер_такта: [(функция, args...), ...]}
# Это просто демонстрация для README/презентации; полноценный CLI/API
# для ручного управления операциями — вне рамок недельного MVP.
DEMO_ACTIONS = {
    3: [("rework", "b1")],
    5: [("priority", "b4", 1)],       # b4 получает наивысший приоритет
    7: [("return", "b1", 0)],          # b1 возвращается в начало очереди
}


def _run_demo_actions(state, tick_number: int) -> None:
    for action in DEMO_ACTIONS.get(tick_number, []):
        kind = action[0]
        if kind == "rework":
            _, body_id = action
            print(f">>> Демо: send_to_rework({body_id!r})")
            send_to_rework(state, body_id)
        elif kind == "return":
            _, body_id, position = action
            print(f">>> Демо: return_to_line({body_id!r}, position={position})")
            return_to_line(state, body_id, position)
        elif kind == "priority":
            _, body_id, new_priority = action
            print(f">>> Демо: change_priority({body_id!r}, {new_priority})")
            change_priority(state, body_id, new_priority)
        print_line_state(state)


def main() -> None:
    num_ticks = int(sys.argv[1]) if len(sys.argv) > 1 else DEFAULT_TICKS

    state = load_config(DEFAULT_CONFIG_PATH)
    print("Линия успешно загружена из конфига:", DEFAULT_CONFIG_PATH)
    print_line_state(state)

    for i in range(1, num_ticks + 1):
        tick(state)
        print_line_state(state)
        _run_demo_actions(state, i)

    print_event_log(state)


if __name__ == "__main__":
    main()
