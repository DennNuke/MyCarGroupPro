"""Консольная визуализация состояния линии (без графики, просто текст)."""

from models import LineState


def print_line_state(state: LineState) -> None:
    print(f"\n=== Такт {state.tick} ===")

    print("\nСтанции:")
    for st in state.stations_sorted():
        if st.occupied_by:
            body = state.bodies[st.occupied_by]
            occ = f"занята: {body.model} ({st.occupied_by}, {body.vin}) — {st.ticks_spent}/{st.processing_ticks} тактов"
        else:
            occ = "свободна"
        print(f"  [{st.order}] {st.name:<22} ({st.id}) — {occ}")

    print("\nВходная очередь:")
    if not state.input_queue:
        print("  (пусто)")
    else:
        for body_id in state.input_queue:
            body = state.bodies[body_id]
            print(f"  {body_id}: {body.model} ({body.vin}), приоритет={body.priority}")

    print("\nБуфер доработки:")
    if not state.rework_buffer:
        print("  (пусто)")
    else:
        for body_id in state.rework_buffer:
            body = state.bodies[body_id]
            print(f"  {body_id}: {body.model} ({body.vin})")

    print()


def print_event_log(state: LineState, last_n: int | None = None) -> None:
    """Печатает журнал событий. Если last_n задан — только последние N записей."""
    entries = state.event_log if last_n is None else state.event_log[-last_n:]
    print("\n=== Журнал событий ===")
    if not entries:
        print("  (пусто)")
        return
    for e in entries:
        print(f"  [такт {e['tick']:>3}] {e['type']:<16} кузов={e['body_id']:<4} {e['from']} -> {e['to']}")
    print()
